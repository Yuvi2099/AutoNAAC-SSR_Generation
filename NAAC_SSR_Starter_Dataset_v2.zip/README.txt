NAAC SSR starter dataset (synthetic demo data)

This ZIP contains CSV tables for student, faculty, placement, research and activity records,
a high-level NAAC criterion starter map, and JSONL extraction examples.

IMPORTANT:
- All records are fictional and for software prototyping/testing only.
- This is NOT an official NAAC dataset and must NOT be submitted as institutional evidence.
- Verify exact metric numbers, wording and evidence requirements against the current NAAC
  framework/manual applicable to the institution and assessment cycle.
- Use institution-authorized, anonymized documents for real SSR generation.
- For RAG, index official NAAC framework documents and authorized institutional documents;
  preserve source filename, page, academic year, institution and access permissions.
